from flask import Flask, render_template, request, redirect, url_for, flash
import os
import torch
import torchvision.transforms as transforms
from model.load_model import mobilenetV2
import json
from PIL import Image
from werkzeug.utils import secure_filename
from werkzeug.datastructures import  FileStorage

app = Flask(__name__)
app.secret_key = "your_secret_key"

model = mobilenetV2() # initialize your PyTorch model here
model.eval()
print("Model Downloaded")
device = 'cpu'


with open('./model/num_to_disease_info.json') as json_file:
    num_to_labels = json.load(json_file)

@torch.no_grad()
def predict(img_path):
    image = Image.open(img_path).convert('RGB')
    resize = transforms.Compose(
             [ transforms.Resize(224),
              transforms.ToTensor()])              
    image = resize(image)
    image = image.to(device)

    with torch.no_grad():
        y_result = torch.softmax(model(image.unsqueeze(0)),dim=1)
        result_idx = int(y_result.argmax(dim=1)[0])
    if(float(y_result.max(dim=1)[0]) < 0.75):
        return "unclear"
    return num_to_labels[str(result_idx)]



@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        results = []  # Store results for each uploaded image

        # Check if the post request has the file part
        if "image" not in request.files:
            flash("No file part")
            return redirect(request.url)

        files = request.files.getlist("image")  # Get a list of uploaded files
        diseases_dict = {}
        unclear_images = []
        for file in files:
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
                file.save(file_path)
                prediction = predict(file_path)

                if prediction == "unclear":
                    plant = "unclear"
                    disease = "unclear"
                    remedy = "na"
                    desc = "na"
                    unclear_images.append(filename)
                else:
                    plant = (" ".join(prediction["disease"].split("__")[0].split("_"))).strip()
                    disease = (" ".join(prediction["disease"].split("__")[1].split("_"))).strip()
                    if disease == "healthy":
                        remedy = "na"
                        desc = "na"
                    else:
                        remedy = prediction.get("Possible Steps", "na")
                        desc = prediction.get("description", "na")

                    if(disease in diseases_dict):
                        (diseases_dict[disease])["images"].append(filename)
                    else:
                        diseases_dict[disease]= {"remedy": remedy,"desc": desc,"images":[filename]}
                        


        diseases_dict["Unclear"]= {"remedy":"na","desc":"na","images":unclear_images}  
        return render_template("index.html", results=diseases_dict, counts = len(diseases_dict))
    return render_template("index.html")


# define allowed file types
ALLOWED_EXTENSIONS = {"jpg", "jpeg", "png"}

def allowed_file(filename):
    return "." in filename and \
           filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

# configure upload folder and maximum file size
app.config["UPLOAD_FOLDER"] = os.path.join("static","uploads")
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024 # 10MB

if __name__ == "__main__":
    app.run(debug=True)
